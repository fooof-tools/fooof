"""
Extract Bands
=============
"""
###############################################################################
# This is a test example.
#

###############################################################################

import numpy as np

# FOOOF imports
from fooof import FOOOF, FOOOFGroup
from fooof.analysis import get_band_peak, get_band_peak_group

###############################################################################

print('Hello World.')
