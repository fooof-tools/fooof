"""
Fit FOOOFGroup 3D
=================
"""
###############################################################################
# This is a test example.
#

###############################################################################

import numpy as np

# FOOOF imports
from fooof import fit_fooof_group_3d

###############################################################################
#
# Fit with fit_fooof_group_3d

fit_fooof_group_3d()
